package com.gruposiete.hotlinemiauami;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotlinemiauamiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotlinemiauamiApplication.class, args);
	}

}
